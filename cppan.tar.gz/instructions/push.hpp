#pragma once

#include <cstdint>

namespace cai
{
    namespace instructions
    {

    }
}
