#pragma once

#include "instruction.hpp"

namespace cai
{
    namespace instructions
    {
        template <size_t ...operands>
        struct decode_operands;


    }
}